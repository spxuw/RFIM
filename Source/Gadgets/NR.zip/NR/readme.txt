README file for NUMERICAL RECIPES C++/C CDROM, WINDOWS AND MACINTOSH
VERSION 2.11 (C++) AND 2.10 (C)

The contents of this CDROM are copyright (C) 1986-2002 by Numerical
Recipes Software.

Please read the file license.txt for Disclaimer of Warranty and for
license terms and conditions.

There are three ways to use this CDROM:

1.  Drag and drop files on your computer desktop from this CDROM to
any desired working directories (folders).  All of the computer source
files are fully unpacked and ready to use.  They are ordinary text
files.  With a bit of exploration, you will easily understand the
directory (folder) organization of the CDROM.  You can also copy the
files by the appropriate command line commands in a DOS window or
other shell.

2.  Navigate on this CDROM with your web browser.  To do this, simply
use your web browser to open the file index.htm in the top-level
directory of the CDROM.  Web links will then guide you through the
CDROM.  You can use your web browser to save (copy) files of your
choice to any desired directory on your hard disk.

3.  Install the version 2.11/2.10 C++/C files directly to your hard disk
drive.  For this purpose, a self-extracting archive file is provided
in the top-level directory of the CDROM as a self-extracting .exe file
(NR_C211_win.exe).  Just double-click on this file to begin the
extraction process.
